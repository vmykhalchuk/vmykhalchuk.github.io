var func1 = function() {
  const para = document.createElement("td"); para.id="hhh";
	const node = document.createTextNode("This is new.");
	para.appendChild(node);

	const element = document.getElementById("div1");
	const child = document.getElementById("p1");
	element.insertBefore(para, child);
}

var ctx = {
  x: 0, y: 0,
  width: 4, height: 5,
  
  editingCell: false,
  mainInputModified: false
}

function deselectCell(x, y) {
  var cellTd = document.getElementById("d_"+y+"_"+x);
  cellTd.className = "cellNotSelected";
}

function selectCell(x, y, movingUp) {
  var cellTd = document.getElementById("d_"+y+"_"+x);
  cellTd.className = "cellSelected";
  
  scrollIntoViewIfNeeded(cellTd);//cellTd.scrollIntoView(movingUp);
  
  // load more data if needed
  if (y == 3) {
    var page = {from: -10, to: 0, records: []};
    var onRecordFn = function(rec) {
      page.records.push(rec);
    }
    var onPageLoadedFn = function() {
      var mainTable = document.getElementById("mainTable");
      ctx.width = 5;
      ctx.height += page.to - page.from;
      for (var i = 0; i < 10; i++) {
        const record = page.records[i];
        const recordId = record.id;
        const row = mainTable.insertRow(0);//as a first record
        for (var j = 0; j < ctx.width; j++) {
          const cell = row.insertCell(-1);
          cell.id="d_" + recordId + "_" + j;
          cell.onclick=myCellClickHandler_v2;
          cell.ondblclick=myCellDblClickHandler_v2;
          cell.onkeydown=myCellOnKeyDown;
          if (j == 0 || j == 1) {
            var svg   = document.createElementNS("http://www.w3.org/2000/svg", "svg");
            var svgNS = svg.namespaceURI;
            svg.setAttribute('width',8);
            svg.setAttribute('height',"24");
            svg.setAttribute('display','block');
            svg.setAttribute('object-fit','cover');
            
            //svg.setAttribute('viewBox',[0,0,10,64]);
            //svg.setAttribute('preserveAspectRatio','xMinYMin');

            var rect = document.createElementNS(svgNS,'rect');
            rect.setAttribute('x',3);
            rect.setAttribute('y',0);
            rect.setAttribute('width',2);
            rect.setAttribute('height',24);
            rect.setAttribute('fill','#95B3D7');
            svg.appendChild(rect);
            cell.appendChild(svg);

            //cell.style.padding="0px 2px 0px 2px";
            cell.style.padding="0px 0px 0px 0px";
            cell.style.borderLeftWidth="2px";
            cell.style.borderLeftStyle="solid";

          } else {
            var textVal;
            if (j == 2) textVal = record.id;
            if (j == 3) textVal = record.name;
            if (j == 4) textVal = record.value;
            const cellText = document.createTextNode(textVal);
            cell.appendChild(cellText);

            cell.style.borderWidth="1px";
            cell.style.borderColor="grey";
            cell.style.borderTopStyle="solid";
            cell.style.borderRightStyle="solid";
          }
        }
      }
    }
    dsFetch(page.from, page.to, {onRecord: onRecordFn, onCompleted: onPageLoadedFn});
  }
}

function scrollIntoViewIfNeeded(cellTd) {
  const mainRect = document.getElementById("main01").getBoundingClientRect();
  const rect = cellTd.getBoundingClientRect();
  console.log("4up: top: " + (rect.top - mainRect.top) + " bottom: " + (rect.bottom - mainRect.top));
  if ((rect.top - mainRect.top)<0 || (rect.bottom - mainRect.top)<0) {
    cellTd.scrollIntoView(true);
  }
  console.log("4dn: top: " + (mainRect.bottom - rect.top) + " bottom: " + (mainRect.bottom - rect.bottom));
  if ((mainRect.bottom - rect.top)<0 || (mainRect.bottom - rect.bottom)<0) {
    cellTd.scrollIntoView(false);
  }
}
  
function myMove(dx, dy) {
  deselectCell(ctx.x, ctx.y);
  if (dx == 1 && ctx.x < (ctx.width - 1)) {
    ctx.x++;
  } else if (dx == -1 && ctx.x > 0) {
    ctx.x--;
  } else if (dy == 1 && ctx.y < (ctx.height - 1)) {
    ctx.y++;
  } else if (dy == -1 && ctx.y > 0) {
    ctx.y--;
  }
  selectCell(ctx.x, ctx.y);
}

function myCellClickHandler(cell) {
  deselectCell(ctx.x, ctx.y);
  ctx.x = parseInt(cell.id.split('_')[2]);
  ctx.y = parseInt(cell.id.split('_')[1]);
  selectCell(ctx.x, ctx.y);
}

function myCellClickHandler_v2(e) {
 	e = e || window.event;

  myCellClickHandler(e.target);

  var cellWasAlreadySelected = (ctx.lastCellClickedX == ctx.x) && (ctx.lastCellClickedY == ctx.y);
  ctx.lastCellClickedX = ctx.x;
  ctx.lastCellClickedY = ctx.y;

  if (cellWasAlreadySelected) editCellStart();
}

function myCellDblClickHandler_v2(e) {
 	e = e || window.event;
  const cell = e.target;
  myCellClickHandler(cell);
  editCellStart();
}

function myCellOnKeyDown(e) {
  e = e || window.event;
  if (e.keyCode == '13') { // Enter
    var cellTd = document.getElementById("d_"+ctx.y+"_"+ctx.x);
    cellTd.contentEditable = false;
    cellTd.blur();
    ctx.editingCell = false;
  } else if (e.keyCode == '27') { // Esc
    var cellTd = document.getElementById("d_"+ctx.y+"_"+ctx.x);
    cellTd.contentEditable = false;
    cellTd.blur();
    ctx.editingCell = false;
  }
}

function initialize() {
  var page = {from: 00, to: 40, records: []};
  
  var onPageLoadedFn = function() {
    var mainTable = document.getElementById("mainTable");
    ctx.width = 5;
    ctx.height = page.to - page.from;
    for (var i = 0; i < ctx.height; i++) {
      const record = page.records[i];
      const recordId = record.id;
      const row = mainTable.insertRow(-1);
      for (var j = 0; j < ctx.width; j++) {
        const cell = row.insertCell(-1);
        cell.id="d_" + recordId + "_" + j;
        cell.onclick=myCellClickHandler_v2;
        cell.ondblclick=myCellDblClickHandler_v2;
        cell.onkeydown=myCellOnKeyDown;
        if (j == 0 || j == 1) {
          var svg   = document.createElementNS("http://www.w3.org/2000/svg", "svg");
          var svgNS = svg.namespaceURI;
          svg.setAttribute('width',8);
          svg.setAttribute('height',"24");
          svg.setAttribute('display','block');
          svg.setAttribute('object-fit','cover');
          
          //svg.setAttribute('viewBox',[0,0,10,64]);
          //svg.setAttribute('preserveAspectRatio','xMinYMin');

          var rect = document.createElementNS(svgNS,'rect');
          rect.setAttribute('x',3);
          rect.setAttribute('y',0);
          rect.setAttribute('width',2);
          rect.setAttribute('height',24);
          rect.setAttribute('fill','#95B3D7');
          svg.appendChild(rect);
          cell.appendChild(svg);

          //cell.style.padding="0px 2px 0px 2px";
          cell.style.padding="0px 0px 0px 0px";
          cell.style.borderLeftWidth="2px";
          cell.style.borderLeftStyle="solid";

        } else {
          var textVal;
          if (j == 2) textVal = record.id;
          if (j == 3) textVal = record.name;
          if (j == 4) textVal = record.value;
          const cellText = document.createTextNode(textVal);
          cell.appendChild(cellText);

          cell.style.borderWidth="1px";
          cell.style.borderColor="grey";
          cell.style.borderTopStyle="solid";
          cell.style.borderRightStyle="solid";
        }
      }
    }

    selectCell(ctx.x, ctx.y);
  }
  
  var onRecordFn = function(rec) {
    page.records.push(rec);
  }
  
  dsFetch(page.from, page.to, {onRecord: onRecordFn, onCompleted: onPageLoadedFn});
}

function editCellStart() {
  if (ctx.mainInputModified) {
    beep();
    alert("Input was modified and not saved!!!");
  } else {
    ctx.editingCell = true;
    var cellTd = document.getElementById("d_"+ctx.y+"_"+ctx.x);
    //var mainInput = document.getElementById("mainInput");
    //mainInput.value = cellTd.innerText;
    //mainInput.focus();
    cellTd.contentEditable = true;
    cellTd.focus();
  }
}


window.onload= function() {
  initialize();
	/*document.getElementById('div1').onclick = function(e) {
 		e = e || window.event;

		//e.target.style["font-weight"] = "bold";
    e.target.className = "ex2";
  	//alert("Clicked: " + e.target.id);
    
		//var who= e.target || e.srcElement: '';
		//if(who.tagName== 'TD') alert(who.id);
	}*/
  
  const mainInput = document.getElementById("mainInput");
  if (mainInput) {
    mainInput.onkeydown = function(e) {
      e = e || window.event;
      if (e.keyCode == '13') { // Enter
        var cellTd = document.getElementById("d_"+ctx.y+"_"+ctx.x);
        cellTd.innerText = mainInput.value;
        mainInput.value="";
        mainInput.blur();
      } else if (e.keyCode == '27') { // Esc
        mainInput.value="";
        mainInput.blur();
      }
    };
  }
  
  document.onkeydown = function(e) {
  	e = e || window.event;
    
    var isMainInputAtFocus = document.activeElement.id == "mainInput";

    if (ctx.editingCell || isMainInputAtFocus) {
      return;
    }
    
    if (e.keyCode == '38') { // up arrow
      myMove(0,-1);
    }
    else if (e.keyCode == '40') { // down arrow
      myMove(0,1);
    }
    else if (e.keyCode == '37') { // left arrow
      myMove(-1,0);
    }
    else if (e.keyCode == '39') { // right arrow
      myMove(1,0);
    }
    else if (e.keyCode == '113') { // F2
      editCellStart();
      e.preventDefault();
    }
    else {
      // F2   -> 113
      // Shft -> 16
      // Ctrl -> 17
      // Alt  -> 18
      //alert("Pressed: " + e.keyCode);
      console.log("onkeydown:" + e.keyCode);
    }
  };
  
  document.onkeypress = function(e) {
  	e = e || window.event;
    console.log("onkeypress:" + e.keyCode);
  };
}