/*
  record: {
    id: #number,
    parentId: #number, // this parent must be returned in the result list too
    name: , // short name
  }

*/

var dsCtx = {
  valMap: {}
}

function _dsGetValById(id) {
  if (!dsCtx.valMap.hasOwnProperty("_" + id)) {
    dsCtx.valMap["_" + id] = getRandomInt(100);
  }
  return dsCtx.valMap["_" + id];
}

function _dsGetRecordById(id) {
  var val = _dsGetValById(id);
  return {id: id, name: "n#" + id, value: val};
}

function dsFetch(from, to, dataCallback) {
  f = function() {dataCallback.onCompleted();}
  tCb = function() {
    for (id = from; id < to; id++) {
      dataCallback.onRecord(_dsGetRecordById(id));
    }
    setTimeout(f, 20);
  }
  setTimeout(tCb, 300);
}

function dsFetchParents(parentIds, dataCallback) {
  f = function() {dataCallback.onCompleted();}
  tCb = function() {
    for (i = 0; i < parentIds.length; i++) {
      var id = parentIds[i];
      dataCallback.onRecord(_dsGetRecordById(id));
    }
    setTimeout(f, 20);
  }
  setTimeout(tCb, 200);
}


/*
    EXAMPLE DATA
    
  0: "MY NOTES" / "notes_book"
    101: "House" / "notes_folder"
      105: "Daily" / "notes_folder"
        111: "Electricity" / "text_note"
    102: "Daily ideas"

*/